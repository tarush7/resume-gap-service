import asyncio

from fastapi import FastAPI, HTTPException

from app.schemas import (
	JobSearchRequest,
	JobSearchResponse
)

from app.services.jobspy_service import (
    scrape_indeed_jobs,
    scrape_naukri_jobs
)


app = FastAPI(
    title="Job Discovery Service",
    version="0.1.0"
)


@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "job-discovery-service",
        "version": "0.1.0"
    }


@app.post(
    "/v1/jobs/scrape",
    response_model=JobSearchResponse
)
async def scrape_jobs(
    request: JobSearchRequest
):
    try:
        if request.source == "indeed":
            jobs = await asyncio.to_thread(
                scrape_indeed_jobs,
                request.searchTerm,
                request.location,
                request.country,
                request.resultsWanted,
                request.hoursOld,
                request.descriptionFormat
            )
        
        elif request.source == "naukri":
            jobs = await asyncio.to_thread(
                scrape_naukri_jobs,
                request.searchTerm,
                request.location,
                request.country,
                request.resultsWanted,
                request.hoursOld,
                request.descriptionFormat
            )

        else:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Unsupported source: "
                    f"{request.source}"
                )
            )

    except HTTPException:
        raise

    except Exception as error:
        raise HTTPException(
            status_code=502,
            detail={
                "message":
                    "Job scraping failed.",

                "source":
                    request.source,

                "error":
                    str(error)
            }
        )

    return {
        "source":
            request.source,

        "discoveryProvider":
            "jobspy",

        "requested":
            request.resultsWanted,

        "returned":
            len(jobs),

        "searchTerm":
            request.searchTerm,

        "location":
            request.location,

        "country":
            request.country,

        "jobs":
            jobs
    }
