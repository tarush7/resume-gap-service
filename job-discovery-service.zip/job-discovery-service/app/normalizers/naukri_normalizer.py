from urllib.parse import urlsplit, urlunsplit


def clean_text(value):
    if value is None:
        return None

    text = str(value).strip()

    if not text:
        return None

    if text.lower() in {
        "none",
        "nan",
        "nat"
    }:
        return None

    return text


def canonicalize_url(value):
    value = clean_text(value)

    if not value:
        return None

    try:
        parts = urlsplit(value)

        return urlunsplit(
            (
                parts.scheme,
                parts.netloc,
                parts.path,
                "",
                ""
            )
        ).rstrip("/")

    except Exception:
        return value.split("?")[0].split("#")[0].rstrip("/")


def get_external_job_id(job):
    jobspy_id = clean_text(
        job.get("id")
    )

    if not jobspy_id:
        return None

    if jobspy_id.startswith("nk-"):
        return jobspy_id[3:]

    return jobspy_id


def normalize_naukri_job(job):
    job_url = clean_text(
        job.get("job_url")
    )

    return {
        "source":
            "naukri",

        "discoveryProvider":
            "jobspy",

        "externalJobId":
            get_external_job_id(job),

        "title":
            clean_text(
                job.get("title")
            ),

        "company":
            clean_text(
                job.get("company")
            ),

        "location":
            clean_text(
                job.get("location")
            ),

        "postedAt":
            clean_text(
                job.get("date_posted")
            ),

        "employmentType":
            clean_text(
                job.get("job_type")
            ),

        "seniorityLevel":
            clean_text(
                job.get("job_level")
            ),

        "jobFunction":
            clean_text(
                job.get("job_function")
            ),

        "industries":
            clean_text(
                job.get("company_industry")
            ),

        "isRemote":
            job.get("is_remote"),

        "jobLink":
            job_url,

        "canonicalJobUrl":
            canonicalize_url(
                job_url
            ),

        "applyUrl":
            clean_text(
                job.get("job_url_direct")
            ),

        "jobDescription":
            clean_text(
                job.get("description")
            ),

        "rawSourceData": {
            "provider":
                "jobspy",

            "jobspyId":
                clean_text(
                    job.get("id")
                ),

            "payload":
                job
        }
    }