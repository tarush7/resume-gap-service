from urllib.parse import parse_qs, urlparse


def clean_text(value):
    if value is None:
        return None

    text = str(value).strip()

    if not text:
        return None

    if text.lower() in {
        "none",
        "nan",
        "nat"
    }:
        return None

    return text


def clean_url(value):
    url = clean_text(value)

    if not url:
        return None

    # JobSpy can occasionally produce:
    # https://in.indeed.comNone
    if url.lower().endswith("none"):
        return None

    return url


def extract_indeed_job_id(
    job_url: str | None
):
    if not job_url:
        return None

    try:
        parsed_url = urlparse(job_url)

        query_params = parse_qs(
            parsed_url.query
        )

        job_ids = query_params.get("jk")

        if job_ids:
            return clean_text(
                job_ids[0]
            )

    except Exception:
        return None

    return None


def normalize_indeed_job(
    raw_job: dict
) -> dict:

    job_url = clean_url(
        raw_job.get("job_url")
    )

    title = clean_text(
        raw_job.get("title")
    )

    description = clean_text(
        raw_job.get("description")
    )

    external_job_id = (
        extract_indeed_job_id(
            job_url
        )
    )

    return {
        "source":
            "indeed",

        "discoveryProvider":
            "jobspy",

        "externalJobId":
            external_job_id,

        "title":
            title,

        "company":
            clean_text(
                raw_job.get("company")
            ),

        "location":
            clean_text(
                raw_job.get("location")
            ),

        "postedAt":
            clean_text(
                raw_job.get("date_posted")
            ),

        "employmentType":
            clean_text(
                raw_job.get("job_type")
            ),

        "seniorityLevel":
            clean_text(
                raw_job.get("job_level")
            ),

        "jobFunction":
            clean_text(
                raw_job.get("job_function")
            ),

        "industries":
            clean_text(
                raw_job.get(
                    "company_industry"
                )
            ),

        "isRemote":
            raw_job.get("is_remote"),

        "jobLink":
            job_url,

        "canonicalJobUrl":
            job_url,

        "applyUrl":
            clean_url(
                raw_job.get(
                    "job_url_direct"
                )
            ),

        "jobDescription":
            description,

        "rawSourceData": {
            "provider":
                "jobspy",

            "jobspyId":
                clean_text(
                    raw_job.get("id")
                ),

            "payload":
                raw_job
        }
    }
