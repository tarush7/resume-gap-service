import json

from jobspy import scrape_jobs

from app.normalizers.indeed_normalizer import (
    normalize_indeed_job
)

from app.normalizers.naukri_normalizer import (
    normalize_naukri_job
)


def scrape_indeed_jobs(
    search_term: str,
    location: str,
    country: str,
    results_wanted: int,
    hours_old: int | None,
    description_format: str
) -> list[dict]:

    parameters = {
        "site_name": ["indeed"],
        "search_term": search_term,
        "location": location,
        "results_wanted": results_wanted,
        "country_indeed": country,
        "description_format":
            description_format,
        "verbose": 1
    }

    if hours_old is not None:
        parameters["hours_old"] = (
            hours_old
        )

    jobs = scrape_jobs(
        **parameters
    )

    if jobs is None or jobs.empty:
        return []

    jobs_json = jobs.to_json(
        orient="records",
        date_format="iso",
        force_ascii=False
    )

    raw_jobs = json.loads(
        jobs_json
    )

    normalized_jobs = []

    for raw_job in raw_jobs:

        normalized_job = (
            normalize_indeed_job(
                raw_job
            )
        )

        normalized_jobs.append(
            normalized_job
        )

    return normalized_jobs

def scrape_naukri_jobs(
    search_term,
    location,
    country,
    results_wanted,
    hours_old,
    description_format
):
    scrape_kwargs = {
        "site_name": ["naukri"],

        "search_term":
            search_term,

        "location":
            location,

        "results_wanted":
            results_wanted,

        "description_format":
            description_format,

        "verbose":
            1,

        # Important:
        # JobSpy's Naukri scraper uses this flag
        # to fetch the full description.
        "linkedin_fetch_description":
            True
    }

    if hours_old is not None:
        scrape_kwargs["hours_old"] = (
            hours_old
        )

    jobs_df = scrape_jobs(
        **scrape_kwargs
    )

    if (
        jobs_df is None or
        jobs_df.empty
    ):
        return []

    raw_jobs = json.loads(
        jobs_df.to_json(
            orient="records",
            date_format="iso"
        )
    )

    return [
        normalize_naukri_job(job)
        for job in raw_jobs
    ]
