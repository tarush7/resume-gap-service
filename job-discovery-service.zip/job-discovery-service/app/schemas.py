from typing import Any, Literal

from pydantic import BaseModel, Field


class JobSearchRequest(BaseModel):
    source: Literal["indeed", "naukri"]

    searchTerm: str = Field(
        min_length=2,
        max_length=200
    )

    location: str = Field(
        min_length=2,
        max_length=200
    )

    country: str = "India"

    resultsWanted: int = Field(
        default=10,
        ge=1,
        le=50
    )

    hoursOld: int | None = Field(
        default=24,
        ge=1,
        le=720
    )

    descriptionFormat: Literal[
        "markdown",
        "html"
    ] = "markdown"


class RawSourceData(BaseModel):
    provider: str
    jobspyId: str | None = None
    payload: dict[str, Any]


class NormalizedJob(BaseModel):
    source: str
    discoveryProvider: str

    externalJobId: str | None

    title: str | None
    company: str | None
    location: str | None

    postedAt: str | None
    employmentType: str | None
    seniorityLevel: str | None
    jobFunction: str | None
    industries: str | None

    isRemote: bool | None

    jobLink: str | None
    canonicalJobUrl: str | None
    applyUrl: str | None

    jobDescription: str | None

    rawSourceData: RawSourceData


class JobSearchResponse(BaseModel):
    source: str
    discoveryProvider: str

    requested: int
    returned: int

    searchTerm: str
    location: str
    country: str

    jobs: list[NormalizedJob]
